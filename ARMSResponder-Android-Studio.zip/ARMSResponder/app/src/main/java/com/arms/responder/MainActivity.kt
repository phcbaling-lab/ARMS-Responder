package com.arms.responder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.arms.responder.ui.ARMSApp
import com.arms.responder.ui.theme.ARMSTheme
import com.arms.responder.ui.ARMSViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ARMSTheme {
                val vm: ARMSViewModel = viewModel()
                ARMSApp(vm)
            }
        }
    }
}
