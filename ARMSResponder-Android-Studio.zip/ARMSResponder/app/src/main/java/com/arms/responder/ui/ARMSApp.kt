package com.arms.responder.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.arms.responder.data.IncidentStatus
import com.arms.responder.ui.screens.*

@Composable
fun ARMSApp(vm: ARMSViewModel) {
    val state by vm.state.collectAsState()

    if (!state.loggedIn) {
        LoginScreen(
            loading = state.loading,
            error = state.error,
            onLogin = vm::login
        )
        return
    }

    val nav = rememberNavController()

    Scaffold(
        bottomBar = {
            NavigationBar {
                val current by nav.currentBackStackEntryAsState()
                val route = current?.destination?.route
                NavigationBarItem(
                    selected = route == "home",
                    onClick = { nav.navigate("home") },
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = route == "incident",
                    onClick = { nav.navigate("incident") },
                    icon = { Icon(Icons.Default.Warning, null) },
                    label = { Text("Incident") }
                )
                NavigationBarItem(
                    selected = route == "profile",
                    onClick = { nav.navigate("profile") },
                    icon = { Icon(Icons.Default.Person, null) },
                    label = { Text("Profile") }
                )
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") {
                DashboardScreen(
                    user = state.user,
                    ambulance = state.ambulance,
                    incident = state.incident,
                    onOpenIncident = { nav.navigate("incident") },
                    onSetAvailable = { vm.setDutyStatus(com.arms.responder.data.DutyStatus.AVAILABLE) }
                )
            }
            composable("incident") {
                IncidentScreen(
                    incident = state.incident,
                    onStatus = vm::updateIncidentStatus
                )
            }
            composable("profile") {
                ProfileScreen(
                    user = state.user,
                    onLogout = vm::logout
                )
            }
        }
    }
}
