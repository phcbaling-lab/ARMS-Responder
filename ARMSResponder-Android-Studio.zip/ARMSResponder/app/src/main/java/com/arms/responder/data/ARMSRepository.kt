package com.arms.responder.data

import kotlinx.coroutines.delay

class ARMSRepository {
    private val demoUser = User("USR-001", "Responder Demo", "RESPONDER", "Baling")

    private val demoAmbulance = Ambulance(
        "AMB-001",
        "Baling 01",
        DutyStatus.AVAILABLE,
        listOf("Responder Demo", "Paramedic Demo", "Driver Demo")
    )

    private var incident = Incident(
        id = "INC-2026-00125",
        priority = Priority.RED,
        emergencyType = "Medical Emergency",
        callerName = "Ahmad bin Ali",
        phone = "012-3456789",
        address = "Baling, Kedah",
        latitude = 5.6789,
        longitude = 100.9123,
        notes = "Patient reported unconscious. CPR may be required.",
        status = IncidentStatus.DISPATCHED
    )

    suspend fun login(username: String, password: String): Result<User> {
        delay(500)
        if (username.isBlank() || password.isBlank()) {
            return Result.failure(IllegalArgumentException("Username and password are required"))
        }
        return Result.success(demoUser)
    }

    suspend fun getAmbulance(): Ambulance {
        delay(150)
        return demoAmbulance
    }

    suspend fun getActiveIncident(): Incident? {
        delay(150)
        return incident
    }

    suspend fun updateIncidentStatus(status: IncidentStatus): Incident {
        delay(250)
        incident = incident.copy(status = status)
        return incident
    }

    suspend fun sendLocation(update: LocationUpdate) {
        // Replace this demo method with POST /api/v1/ambulances/{id}/location.
        delay(50)
    }
}
