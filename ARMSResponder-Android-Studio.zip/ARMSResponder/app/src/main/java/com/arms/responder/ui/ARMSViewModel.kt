package com.arms.responder.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.arms.responder.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ARMSUiState(
    val loading: Boolean = false,
    val loggedIn: Boolean = false,
    val user: User? = null,
    val ambulance: Ambulance? = null,
    val incident: Incident? = null,
    val error: String? = null
)

class ARMSViewModel : ViewModel() {
    private val repo = ARMSRepository()
    private val _state = MutableStateFlow(ARMSUiState())
    val state: StateFlow<ARMSUiState> = _state.asStateFlow()

    fun login(username: String, password: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            repo.login(username, password)
                .onSuccess { user ->
                    val ambulance = repo.getAmbulance()
                    val incident = repo.getActiveIncident()
                    _state.value = ARMSUiState(
                        loggedIn = true,
                        user = user,
                        ambulance = ambulance,
                        incident = incident
                    )
                }
                .onFailure {
                    _state.value = _state.value.copy(
                        loading = false,
                        error = it.message ?: "Login failed"
                    )
                }
        }
    }

    fun refreshIncident() {
        viewModelScope.launch {
            _state.value = _state.value.copy(incident = repo.getActiveIncident())
        }
    }

    fun setDutyStatus(status: DutyStatus) {
        _state.value = _state.value.copy(
            ambulance = _state.value.ambulance?.copy(status = status)
        )
    }

    fun updateIncidentStatus(status: IncidentStatus) {
        viewModelScope.launch {
            val updated = repo.updateIncidentStatus(status)
            val ambulanceStatus = when (status) {
                IncidentStatus.ACCEPTED -> DutyStatus.EN_ROUTE
                IncidentStatus.EN_ROUTE -> DutyStatus.EN_ROUTE
                IncidentStatus.ARRIVED -> DutyStatus.AT_SCENE
                IncidentStatus.TRANSPORTING -> DutyStatus.TRANSPORTING
                IncidentStatus.AT_HOSPITAL -> DutyStatus.AT_SCENE
                IncidentStatus.COMPLETED -> DutyStatus.AVAILABLE
                IncidentStatus.DISPATCHED -> DutyStatus.AVAILABLE
            }
            _state.value = _state.value.copy(
                incident = updated,
                ambulance = _state.value.ambulance?.copy(status = ambulanceStatus)
            )
        }
    }

    fun logout() {
        _state.value = ARMSUiState()
    }
}
